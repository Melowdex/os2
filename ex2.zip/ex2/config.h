/**
 * @author {AUTHOR}
 */
#ifndef _CONFIG_H_
#define _CONFIG_H_

#define BUFFER_MAX 512

#endif /* _CONFIG_H_ */
